import datetime
from typing import List, Optional

from pydantic import BaseModel

from prometheus_api_models import Alert


class ToolUsageRecord (BaseModel):
    tool_name: str
    description: str
    result: str

class AlertInvestigationResult (BaseModel):
    tool_usage_records: Optional[List[ToolUsageRecord]] = None
    errors: Optional[List[str]] = None
    ai_analysis: Optional[str] = None
    prompt_used: Optional[str] = None

    def get_tool_usage_summary(self):
        # AI used output of
        return "AI used info from alert and " + ",".join([f"`{record.description}`" for record in self.tool_usage_records])

def get_sample_alert_for_investigation() -> Alert:
    return Alert(
        status="firing",
        labels={
            "alertname": "KubeSchedulerDown",
            "severity": "critical"
        },
        annotations={
            "description": "KubeScheduler has disappeared...",
            "runbook_url": "https://runbooks.prometheus-operator.dev/runbooks/kubernetes/kubeschedulerdown",
            "summary": "Target disappeared from Prometheus target discovery."
        },
        startsAt=datetime.datetime(2023, 12, 29, 11, 38, 7, 928000),
        endsAt=datetime.datetime(1, 1, 1, 0, 0),
        generatorURL="your-generator-url",
        fingerprint="your-fingerprint"
    )

def get_sample_investigation() -> AlertInvestigationResult:
    tool_usage_record = ToolUsageRecord(
        tool_name="kubectl",
        description="kubectl describe -n kube-system kube-scheduler",
        result="Sample result"
    )

    return AlertInvestigationResult(
        tool_usage_records=[tool_usage_record],
        ai_analysis="Kubernetes Scheduler is undetectable by Prometheus."
    )

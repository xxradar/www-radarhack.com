import json
import logging
import textwrap
from typing import Dict, List

from openai import OpenAI, BadRequestError
from openai.types.chat.chat_completion import Choice 
from openai._types import NOT_GIVEN

from config import ConfigFile
from investigation_results import AlertInvestigationResult, ToolUsageRecord
from prometheus_api_models import get_live_alerts
from prometheus_receiver_models import Alert
from slack_sender import SlackSender
from tools import YAMLTool, YAMLToolExecutor


class AIInvestigator:
    def __init__(self, ai_client: OpenAI, tools: List[YAMLTool]):
        self.client = ai_client
        self.tool_executor = YAMLToolExecutor(tools)
        self.max_iterations = 5

    def investigate_alert(self, alert: Alert) -> AlertInvestigationResult:
        prompt = self.__get_default_prompt(alert)
        return self.investigate(prompt)

    def investigate(self, prompt) -> AlertInvestigationResult:
        messages = prompt.copy()
        tool_usage_record = []
        tools = self.tool_executor.get_all_tools_openai_format()

        for i in range(self.max_iterations):
            logging.debug(f"running iteration {i}")
            # on the last iteration we don't allow tools - we want to force a reply, not a request to run another tool
            if i == self.max_iterations - 1:
                logging.debug("last iteration, function calling is forbidden")
                response = self.call_llm(messages)
            else:
                response = self.call_llm(messages, tools)

            response_message = response.message
            messages.append(
                response_message.model_dump(
                    exclude_defaults=True, exclude_unset=True, exclude_none=True
                )
            )

            tools_to_call = response_message.tool_calls
            if not tools_to_call:
                return AlertInvestigationResult(
                    ai_analysis=response_message.content,
                    tool_usage_records=tool_usage_record,
                    prompt_used=json.dumps(messages, indent=2),
                )

            # when asked to run tools, we expect no response other than the request to run tools
            assert not response_message.content

            for t in tools_to_call:
                tool_name = t.function.name
                tool_params = json.loads(t.function.arguments)
                tool = self.tool_executor.get_tool_by_name(tool_name)
                tool_response = tool.invoke(tool_params)
                messages.append(
                    {
                        "tool_call_id": t.id,
                        "role": "tool",
                        "name": tool_name,
                        "content": tool_response,
                    }
                )
                tool_usage_record.append(
                    ToolUsageRecord(
                        tool_name=tool_name,
                        description=tool.get_parameterized_one_liner(tool_params),
                        result=tool_response,
                    )
                )

    def call_llm(self, messages, tools=NOT_GIVEN) -> Choice:
        try:
            return self.client.chat.completions.create(
                    model="gpt-4-1106-preview",
                    messages=messages,
                    tools=tools,
                    tool_choice="auto",
                ).choices[0]
        except BadRequestError as e:
            if 'Unrecognized request arguments supplied: tool_choice, tools' in str(e):
                raise Exception("The Azure model you chose is not supported. Model version 1106 and higher required.")
            else:
                raise
            
    @staticmethod
    def __get_default_prompt(alert: Alert) -> Dict[str, str]:
        prompt = textwrap.dedent(
            f"""\
                Provide a 2-3 sentence summary of the following Prometheus alert and why it is firing: {alert.model_dump_json()}.
                When it can provide extra information, first run as many kubectl commands as you need to gather more information, then respond.
                If possible, do so repeatedly on different Kubernetes objects.
                For example, for deployments first run kubectl on the deployment then a replicaset inside it, then a pod inside that.
                You must use tools to investigate whenever possible.
                In any event, do not reply with more than 3 sentences of total output.
                Be very concise. If you don't know, just say that the analysis was inconclusive.
                If there are multiple possible causes list them in a numbered list.
                When possible, be as specific as you can, but only if refering to exact data from the alert or tool output.
                Do not say 'based on the tool output' or explicitly refer to tools at all.
                Do not give meaningless answers, like the 'KubeDeploymentReplicasMismatch is firing because a deployment has not matched the expected
                replica count for over 15 minutes due to being unable to reach the minimum available replicas' as that is meaningless and we could tell
                as much from the alert description without you. (Users will see both.). 
                Ignore metadata about kube-state-metrics as it is attached to many alerts but not relevant to the error itself.
                And above all else, remember: be concise.
                Do not start your reply with 'The [Prometheus] alert is firing because...' rather get straight to the point.
                Remove every unecessary word.
                _Italicize_ exact names of Kubernetes resources like specific pods using Slack mrkdwn format.
                If the annotation ai_investigation_hint is present, use it to guide your investigation."""
        ).replace("\n", " ")
        initial_messages = [
            {
                "role": "user",
                "content": prompt,
            }
        ]
        return initial_messages


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    config_file = ConfigFile.from_file()
    slack_sender = SlackSender(config_file.destinations.slack)
    investigator = AIInvestigator(config_file)

    # alerts = get_sample_alerts()
    alerts = get_live_alerts("http://localhost:9093")
    for alert in alerts:
        result = investigator.investigate_alert(alert)
        slack_sender.send_single_alert(alert, result)
        # alert.annotations["ai_analysis"] = result

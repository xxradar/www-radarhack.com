from openai import AzureOpenAI, OpenAI
from typing import Optional
from pydantic import BaseModel, SecretStr
from pydantic_utils import load_model_from_file


class AbstractAIConfig(BaseModel):
    def create_client(self):
        raise NotImplementedError()
    

class OpenAIConfig(BaseModel):
    api_key: SecretStr

    def create_client(self):
        return OpenAI(api_key=self.api_key.get_secret_value())


class AzureConfig(BaseModel):
    endpoint: str
    api_key: SecretStr
    api_version: str = "2023-12-01-preview"

    def create_client(self):
        return AzureOpenAI(
            api_key=self.api_key.get_secret_value(),
            azure_endpoint=self.endpoint,
            api_version=self.api_version,
        )
    

class AIProvidersConfig(BaseModel):
    openai: Optional[OpenAIConfig] = None
    azure: Optional[AzureConfig] = None

    def create_client(self):
        if self.openai and self.azure:
            raise Exception("In configuration file, only one of `openai` or `azure` can be set")
        
        if self.openai:
            return self.openai.create_client()
        if self.azure:
            return self.azure.create_client()


if __name__ == "__main__":
    openai_config = load_model_from_file(OpenAIConfig, yaml_path="ai_providers.openai")
    azure_config = load_model_from_file(AzureConfig, yaml_path="ai_providers.azure")
    print("Succeeded in creating LLM clients")
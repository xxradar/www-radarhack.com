import html
import requests
import json
from typing import List, Dict
from pydantic import BaseModel, parse_obj_as
from datetime import datetime
from urllib.parse import urlparse, parse_qs, unquote


class Alert(BaseModel):
    status: str
    labels: Dict[str,str]
    annotations: Dict[str,str]
    startsAt: datetime
    endsAt: datetime
    generatorURL: str = None
    fingerprint: str

    def calculate_duration(self):
        if self.endsAt.year == 1:
            return "Ongoing"
        else:
            duration = self.endsAt - self.startsAt
            return str(duration)

    def get_name(self):
        return self.labels['alertname']
    
    def get_triggering_alert(self):
        url = self.generatorURL
        if not url:
            return ""

        # decode HTML entities to convert &#43; like representations to characters
        url = html.unescape(url)
        parsed_url = urlparse(url)
        query_params = parse_qs(parsed_url.query)

        q_expr = query_params.get("g0.expr", [])
        if len(q_expr) < 1 or not q_expr[0]:
            return ""

        return unquote(q_expr[0])

class AlertGroup(BaseModel):
    receiver: str
    status: str
    alerts: List[Alert]
    groupLabels: Dict[str, str]
    commonLabels: Dict[str, str]
    commonAnnotations: Dict[str, str]
    externalURL: str
    version: str
    groupKey: str
    truncatedAlerts: int

class SampleAlertsData(BaseModel):
    alerts: List[AlertGroup]


def get_sample_alerts(path) -> List[Alert]:
    alert_groups = SampleAlertsData.parse_file(path).alerts
    alerts = []
    for group in alert_groups:
        if len(group.alerts) > 1:
            print(f"For group with more than one alert, only using first alert. Group={group}")
        alerts.append(group.alerts[0])
    return alerts

if __name__ == "__main__":
    alerts = get_sample_alerts("./tmp/sample-prom-alerts.json")
    print(f"loaded {len(alerts)} sample alerts succesfully")

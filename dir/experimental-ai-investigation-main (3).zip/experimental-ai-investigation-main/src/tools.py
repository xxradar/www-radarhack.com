import logging
import re
import subprocess
import sys
import tempfile
from pydantic import BaseModel, validator as model_validator
from pydantic_utils import load_model_from_file
from typing import Optional
from jinja2 import Template
from typing import Dict, List


class YAMLToolParameter(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    type: str = "string"
    required: bool = True


class YAMLTool(BaseModel):
    name: str
    description: str
    title: Optional[str] = None
    command: Optional[str] = None
    script: Optional[str] = None
    parameters: Dict[str, YAMLToolParameter] = {}

    def __init__(self, **data):
        super().__init__(**data)
        self.__infer_parameters()

    #@model_validator(mode="after")
    #def check_runnable(self) -> "YAMLTool":
    #    if (self.command is None and self.script is None) or (
    #        self.command is not None and self.script is not None
    #    ):
    #        raise ValueError("either `command` or `script` must be set, but not both")
    #    return self

    def __infer_parameters(self):
        # Find parameters that appear inside self.command or self.script but weren't declared in parameters
        template = self.command or self.script
        inferred_params = re.findall(r"\{\{\s*(\w+)\s*\}\}", template)
        # TODO: if filters were used in template, take only the variable name
        # Regular expression to match Jinja2 placeholders with or without filters
        # inferred_params = re.findall(r'\{\{\s*(\w+)(\s*\|\s*[^}]+)?\s*\}\}', self.command)
        # for param_tuple in inferred_params:
        #    param = param_tuple[0]  # Extract the parameter name
        #    if param not in self.parameters:
        #        self.parameters[param] = ToolParameter()
        for param in inferred_params:
            if param not in self.parameters:
                self.parameters[param] = YAMLToolParameter()

    def get_openai_format(self):
        tool_properties = {}
        for param_name, param_attributes in self.parameters.items():
            tool_properties[param_name] = { "type": param_attributes.type }
            if param_attributes.title is not None:
                tool_properties[param_name]["title"] = param_attributes.title
            if param_attributes.description is not None:
                tool_properties[param_name]["description"] = param_attributes.description
        
        title = self.title or self.name

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": { 
                    "properties": tool_properties, 
                    "required": [param_name for param_name, param_attributes in self.parameters.items() if param_attributes.required],
                    "title": title,
                    "type": "object", 
                }
            },
        }

    def get_parameterized_one_liner(self, params):
        cmd_or_script = self.command or self.script
        template = Template(cmd_or_script)
        return template.render(params)
    
    def invoke(self, params) -> str:
        if self.command is not None:
            return self.__invoke_command(params)
        else:
            return self.__invoke_script(params)

    def __invoke_command(self, params) -> str:
        template = Template(self.command)
        rendered_command = template.render(params)
        logging.info(f"Running `{rendered_command}`")
        return self.__execute_subprocess(rendered_command)

    def __invoke_script(self, params) -> str:
        template = Template(self.script)
        rendered_script = template.render(params)

        with tempfile.NamedTemporaryFile(
            mode="w+", delete=False, suffix=".sh"
        ) as temp_script:
            temp_script.write(rendered_script)
            temp_script_path = temp_script.name
        subprocess.run(["chmod", "+x", temp_script_path], check=True)

        try:
            return self.__execute_subprocess(temp_script_path)
        finally:
            subprocess.run(["rm", temp_script_path])

    def __execute_subprocess(self, cmd) -> str:
        try:
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True, check=True
            )
            return f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        except subprocess.CalledProcessError as e:
            return f"Command `{cmd}` failed with return code {e.returncode}\nstdout:\n{e.stdout}\nstderr:\n{e.stderr}"


class YAMLToolExecutor:
    def __init__(self, tools: List[YAMLTool]):
        try:
            self.tools = tools
        except Exception as e:
            raise RuntimeError(f"Failed to load or parse YAML configuration: {e}")

        self.name_to_tools = {tool.name: tool for tool in self.tools}

    def invoke(self, tool_name: str, params: Dict) -> str:
        tool = self.get_tool_by_name(tool_name)
        return tool.invoke(params)

    def get_tool_by_name(self, name: str):
        name_to_tools = {tool.name: tool for tool in self.tools}
        return name_to_tools[name]

    def get_all_tools_openai_format(self):
        return [tool.get_openai_format() for tool in self.tools]


# test
if __name__ == "__main__":
    kubectl_tool = load_model_from_file(YAMLTool, yaml_path="tools[0]")
    executor = YAMLToolExecutor([kubectl_tool])
    print(
        executor.invoke(
            "kubectl_describe",
            {
                "kind": "deployment",
                "name": "example-deployment",
                "namespace": "default",
            },
        )
    )

import html
import json
from datetime import datetime
from typing import Dict, List
from urllib.parse import parse_qs, unquote, urlparse

import requests
from pydantic import BaseModel, Field, parse_obj_as

from prometheus_receiver_models import Alert


class Receiver(BaseModel):
    name: str

class AlertStatus(BaseModel):
    state: str
    silencedBy: List[str]
    inhibitedBy: List[str]

class GettableAlert(BaseModel):
    labels: Dict[str, str]
    generatorURL: str
    annotations: Dict[str, str]
    receivers: List[Receiver]
    fingerprint: str
    startsAt: datetime
    updatedAt: datetime
    endsAt: datetime
    status: AlertStatus

def get_live_alerts(alertmanager_url) -> List[Alert]:
    alertmanager_base_url = f"{alertmanager_url}/api/v2/alerts"
    params = {
        "active": "true",
        "silenced": "false",
        "inhibited": "false",
    }
    response = requests.get(alertmanager_base_url, params=params)
    if response.status_code != 200:
        raise Exception(f"Failed to get live alerts: {response.status_code} {response.text}")
    data = response.json()
    alerts = parse_obj_as(List[GettableAlert], data)
    return [Alert(
        status=gettable_alert.status.state,
        labels=gettable_alert.labels,
        annotations=gettable_alert.annotations,
        startsAt=gettable_alert.startsAt,
        endsAt=gettable_alert.endsAt,
        generatorURL=gettable_alert.generatorURL,
        fingerprint=gettable_alert.fingerprint
    ) for gettable_alert in alerts]

if __name__ == "__main__":
    alerts = get_live_alerts("http://localhost:9093")
    print(f"got {len(alerts)} currently firing alerts from alertmanager")

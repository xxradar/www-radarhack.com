from typing import Dict

from pydantic import BaseModel
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

from investigation_results import (AlertInvestigationResult, ToolUsageRecord,
                                   get_sample_alert_for_investigation,
                                   get_sample_investigation)
from prometheus_api_models import Alert
from pydantic_utils import load_model_from_file

class SlackConfig(BaseModel):
    token: str
    channel: str


class SlackSender:
    def __init__(self, slack_config: SlackConfig):
        self.config = slack_config
        self.client = WebClient(token=self.config.token)

    def send_single_alert(
        self, alert: Alert, investigation: AlertInvestigationResult
    ) -> None:
        try:
            color = (
                "#FF0000" if alert.status == "firing" else "#00FF00"
            )  # Red for firing, green for resolved
            link = "https://your-alert-link.com"

            response = self.client.chat_postMessage(
                channel=self.config.channel,
                text=f"*<{link}|{alert.labels['alertname']} - {alert.status}>*",
                attachments=[
                    {
                        "color": color,
                        "blocks": [
                            {
                                # TODO: consider moving outside of block
                                "type": "section",
                                "text": {
                                    "type": "mrkdwn",
                                    "text": f":robot_face: {investigation.ai_analysis}",
                                },
                            },
                            # {
                            #    "type": "section",
                            #    "fields": [
                            #        {
                            #            "type": "mrkdwn",
                            #            "text": f"*Severity*: {alert.labels['severity']}",
                            #        },
                            #        {
                            #            "type": "mrkdwn",
                            #            "text": f"*Start Time*: {alert.startsAt.strftime('%Y-%m-%d %H:%M:%S UTC')}",
                            #        },
                            #        {
                            #            "type": "mrkdwn",
                            #            "text": f"*Duration*: {alert.calculate_duration()}",
                            #        },
                            #    ],
                            # },
                            {
                                "type": "context",
                                "elements": [
                                    {
                                        "type": "mrkdwn",
                                        "text": f"*Severity*: {alert.labels['severity']}\n*Start Time*: {alert.startsAt.strftime('%Y-%m-%d %H:%M:%S UTC')}\n*Duration*: {alert.calculate_duration()}",
                                    }
                                ],
                            },
                            # {
                            #    "type": "context",
                            #    "elements": [
                            #        {
                            #            "type": "mrkdwn",
                            #            "text": investigation.get_tool_usage_summary(),
                            #        }
                            #    ],
                            # },
                        ],
                    }
                ],
            )
            self.__send_tool_usage(response["ts"], investigation)
            self.__send_labels_and_annotations(response["ts"], alert)
            self.__send_prompt_for_debugging(response["ts"], investigation)

        except SlackApiError as e:
            print(f"Error sending message: {e}")

    def __send_tool_usage(
        self, parent_thread, investigation: AlertInvestigationResult
    ) -> None:
        if not investigation.tool_usage_records:
            return

        text = "*AI used info from alert and the following tools:*"
        for tool in investigation.tool_usage_records:
            file_response = self.client.files_upload(
                content=tool.result, title=f"{tool.description}"
            )
            permalink = file_response["file"]["permalink"]
            text += f"\n• `<{permalink}|{tool.description}>`"

        self.client.chat_postMessage(
            channel=self.config.channel,
            thread_ts=parent_thread,
            text=text,
            blocks=[
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": text},
                }
            ],
        )

    def __send_prompt_for_debugging(
        self, parent_thread, investigation: AlertInvestigationResult
    ) -> None:
        if not investigation.prompt_used:
            return

        text = "*🐞 DEBUG: messages with OpenAI*"
        file_response = self.client.files_upload(
            content=investigation.prompt_used, title=f"ai-prompt"
        )
        permalink = file_response["file"]["permalink"]
        text += f"\n• `<{permalink}|ai-prompt>`"

        self.client.chat_postMessage(
            channel=self.config.channel,
            thread_ts=parent_thread,
            text=text,
            blocks=[
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": text},
                }
            ],
        )

    def __send_labels_and_annotations(self, parent_thread, alert: Alert) -> None:
        if not alert.labels and not alert.annotations:
            return

        text = ""
        if alert.labels:
            text += "*Labels:*\n"
            text += self.__get_table(alert.labels)
        if alert.annotations:
            text += "*Annotations:*\n"
            text += self.__get_table(alert.annotations)

        self.client.chat_postMessage(
            channel=self.config.channel,
            thread_ts=parent_thread,
            text="Prometheus Alert Metadata...",
            unfurl_links=False,
            unfurl_media=False,
            blocks=[
                {
                    "type": "section",
                    "text": {"text": "*Prometheus Alert Metadata*", "type": "mrkdwn"},
                },
                {
                    "type": "context",
                    "elements": [
                        {
                            "type": "mrkdwn",
                            "text": text,
                        }
                    ],
                },
            ],
        )

    def __get_table(self, items: Dict[str, str]) -> str:
        if not items:
            return ""

        text = ""
        for k, v in items.items():
            # TODO: if v is a url, linkify it
            text += f"• *{k}*: {v}\n"

        return text


if __name__ == "__main__":
    config = load_model_from_file(SlackConfig, yaml_path="destinations.slack")
    sender = SlackSender(config)
    alert = get_sample_alert_for_investigation()
    investigation = get_sample_investigation()
    sender.send_single_alert(alert, investigation)

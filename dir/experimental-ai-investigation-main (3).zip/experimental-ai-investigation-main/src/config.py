from typing import Dict, List

from pydantic import BaseModel

from llms import AIProvidersConfig
from pydantic_utils import load_model_from_file
from slack_sender import SlackConfig
from tools import YAMLTool


class DestinationsConfig(BaseModel):
    slack: SlackConfig


class Runbook(BaseModel):
    alerts: List[str]
    instructions: str


class ConfigFile (BaseModel):
    destinations: DestinationsConfig
    ai_providers: AIProvidersConfig
    tools: List[YAMLTool] = []
    runbooks: List[Runbook] = []
    
    @classmethod
    def from_file(cls, file_path: str = "config.yaml") -> 'ConfigFile':
        return load_model_from_file(cls, file_path)

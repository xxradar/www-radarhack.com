import logging
import warnings

from openai import OpenAI
import typer

from src.investigator import AIInvestigator
from src.prometheus_api_models import get_live_alerts, Alert
from src.slack_sender import SlackSender
from src.config import ConfigFile

# Suppress UserWarnings from the slack_sdk module
warnings.filterwarnings("ignore", category=UserWarning, module='slack_sdk.*')


app = typer.Typer(add_completion=False)

def preprocess_alert(alert: Alert, config: ConfigFile):
    alert.annotations["triggering_promql"] = f"`{alert.get_triggering_alert()}`"
    alert_name = alert.get_name()
    for runbook in config.runbooks:
        if alert_name in runbook.alerts:
            alert.annotations["ai_investigation_hint"] = runbook.instructions


@app.command()
def analyze_alerts(alertmanager_url=typer.Argument(help="e.g. localhost:9093"),
                   name_filter=typer.Option(None, help="Only analyze alerts with this name")):
    """
    Fetch all currently firing alerts, analyze them, and send results to Slack.
    """
    config = ConfigFile.from_file()
    slack_sender = SlackSender(config.destinations.slack)
    ai_client = config.ai_providers.create_client()
    investigator = AIInvestigator(ai_client, config.tools)

    logging.info(f"Fetching alerts from {alertmanager_url}...")
    alerts = get_live_alerts(alertmanager_url)
    if name_filter:
        alerts = [a for a in alerts if a.get_name() == name_filter]

    logging.info(f"Analyzing {len(alerts)} alerts. Press Ctrl+C to stop at any time.")
    # alerts = get_sample_alerts()
    for (i, alert) in enumerate(alerts):
        logging.info(f"Analyzing alert {i+1}/{len(alerts)}: {alert.get_name()}...")
        preprocess_alert(alert, config)
        result = investigator.investigate_alert(alert)
        logging.info(f"Sending result to Slack channel {config.destinations.slack.channel}")
        slack_sender.send_single_alert(alert, result)
        # alert.annotations["ai_analysis"] = result


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    logging.getLogger("httpx").setLevel(logging.WARNING) # disable INFO logs from OpenAI
    app()

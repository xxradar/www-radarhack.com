# AI Alert Analyzer

This an experimental project to automatically investigate cloud alerts using AI.

![AI Alert Analysis](images/preview.png)

## Features:
1. **High-accuracy results:** achieved by augmenting an LLM with live data from other sources
2. **Extensible**: teach the LLM to gather data from your own sources, in only a few lines of YAML

## Limitations
At present:

1. Only Prometheus alerts are supported
2. Results can only be sent to Slack
3. It runs as a local CLI tool
4. It pulls alerts from AlertManager instead of listening for alerts via webhook receiver

## How it works
The tool:

1. Reads live alerts from AlertManager
2. **Uses an LLM to figure out what data is necessary for the investigation** (using [function-calling capabilities](https://platform.openai.com/docs/guides/function-calling))
3. **Gathers that data outside of the LLM**
4. Completes the analysis with another LLM call

By augmenting an LLM with data-gathering capabilities, we've been able to achieve a high level of accuracy.

## Getting Started

1. [Install poetry (the python package manager)](https://python-poetry.org/docs/#installing-with-the-official-installer)

2. Install python dependencies with:

```bash
poetry install --no-root
```

3. Install [kube-lineage](https://github.com/tohjustin/kube-lineage). This is one of the default tools in `config.yaml` that the LLM uses to investigate

4. Edit `config.yaml`, filling in all missing fields

5. Analyze all currently firing alerts (replacing `localhost:9093` with AlertManager's actual URL):

```bash
poetry run python main.py localhost:9093
```

## Customization
See `config.yaml`.